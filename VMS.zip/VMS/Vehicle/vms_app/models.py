from django.db import models
from django.core.validators import RegexValidator

# Create your models here.
class Admin(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    password = models.CharField(max_length=100)

alphanumeric = RegexValidator(r'^[0-9a-zA-Z]*$', 'Only alphanumeric characters are allowed.')

class Vehicle_details(models.Model):
    number = models.CharField(max_length=20, validators=[alphanumeric])
    vehicle_type = models.IntegerField()
    vehicle_model = models.CharField(max_length=100)
    description = models.CharField(max_length=200)