from django.shortcuts import render, redirect, HttpResponse
from .forms import SuperAdminForm, SuperAdminLoginForm, AdminForm, Add_vehicle
from django.contrib import messages
from .models import Admin, Vehicle_details
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User


def SuperAdminRegister(request):
    if request.method == 'POST':
        form = SuperAdminForm(request.POST)
        
        if form.is_valid():
            form.save()

            username = form.cleaned_data.get('username')
            messages.success(request, f'Welcome {username} , Your account has been created successfully. ')

            return redirect(to='/')

        return render(request, 'super_register.html', {'form': form})
    else:
        form = SuperAdminForm()
        return render(request, 'super_register.html', {'form': form})


def super_admin_signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('/add_show_vehicle')
            
        else:
            fm = SuperAdminLoginForm()
            return render(request, 'super_admin_signin.html', {'form':fm})
    else:
        fm = SuperAdminLoginForm()
        return render(request, 'super_admin_signin.html', {'form':fm})




def AdminSignup(request):
    if request.method == 'POST':
        fm = AdminForm(request.POST)
        
        if fm.is_valid():
            fm.save()

            username = fm.cleaned_data.get('username')
            messages.success(request, f'Welcome {username} , Your account has been created successfully. ')

            return redirect(to='/admin_signin')

        return render(request, 'admin_signup.html', {'form': fm})
    else:
        fm = AdminForm()
        return render(request, 'admin_signup.html', {'form': fm})

def admin_signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        users = Admin.objects.all().filter(username=username, password=password)
        
        for user in users:
            if user.username==username and user.password==password:
                
                return redirect('/edit_view')    
        else:
            return render(request, 'admin_signin.html')
    else:
        return render(request, 'admin_signin.html')

    return render(request, 'admin_signin.html')

def edit_view(request):
    
    vehicle = Vehicle_details.objects.all()
    return render(request, 'edit_view.html', {'vehicle':vehicle})


def edit_view2(request, id):
    if request.method == 'POST':
        p = Vehicle_details.objects.get(pk=id)
        f = Add_vehicle(request.POST, instance=p)
        if f.is_valid():
            f.save()
    else:
        p = Vehicle_details.objects.get(pk=id)
        f = Add_vehicle(instance=p)
    return render(request, 'edit_view2.html', {'form':f})



def Add(request):
    if request.method == 'POST':
        fm = Add_vehicle(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['number']
            vt = fm.cleaned_data['vehicle_type']
            vm = fm.cleaned_data['vehicle_model']
            ds = fm.cleaned_data['description']
            bk = Vehicle_details(number=nm, vehicle_type=vt, vehicle_model=vm, description=ds)
            bk.save()
            fm = Add_vehicle()
    else:
        fm = Add_vehicle()
    vehicle = Vehicle_details.objects.all()
    
    return render(request, 'add_show_vehicle.html',{'form':fm, 'vehicle':vehicle})


def edit(request, id):
    if request.method == 'POST':
        pi = Vehicle_details.objects.get(pk=id)
        fm = Add_vehicle(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = Vehicle_details.objects.get(pk=id)
        fm = Add_vehicle(instance=pi)
    
    return render(request, 'edit.html', {'form':fm})


def delete_vehicle(request, id):
    if request.method == 'POST':
        pi = Vehicle_details.objects.get(pk=id)
        pi.delete()
        return redirect('showallvehicles')


def user_view(request):
    vehicle = Vehicle_details.objects.all()
    return render(request, 'user_view.html', {'vehicle':vehicle})


def signout(request):
    logout(request)
    return redirect('home')